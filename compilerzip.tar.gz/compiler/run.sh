#!/bin/bash

# Activate virtual environment
source venv/bin/activate

echo "==================================="
echo "Sixenine Language Examples Runner"
echo "==================================="
echo

echo "1. Running Calculator Example"
echo "----------------------------"
python3 -m sixenine.src.run sixenine/examples/calculator.sn
echo

echo "2. Running Pattern Example"
echo "-------------------------"
python3 -m sixenine.src.run sixenine/examples/pattern.sn
echo

echo "3. Running Number Game Example"
echo "----------------------------"
python3 -m sixenine.src.run sixenine/examples/number_game.sn
echo

# Deactivate virtual environment
deactivate 