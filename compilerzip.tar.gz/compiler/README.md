# Sixenine Programming Language

Sixenine is a simple programming language that supports basic programming constructs like variables, functions, loops, and conditional statements.

## Installation

1. Make sure you have Python 3.6+ installed
2. Install the required dependencies:
```bash
pip install -r requirements.txt
```

## Language Features

- Variables and arithmetic operations
- Functions with parameters
- While loops
- If-else statements
- Print statements
- Comments (using #)

## Syntax Examples

### Variables and Arithmetic
```
x = 5;
y = x + 3;
print(y);
```

### Functions
```
func add(a, b) {
    return a + b;
}
result = add(5, 3);
print(result);
```

### While Loops
```
i = 0;
while (i < 5) {
    print(i);
    i = i + 1;
}
```

### If-Else Statements
```
x = 10;
if (x > 5) {
    print("x is greater than 5");
} else {
    print("x is less than or equal to 5");
}
```

## Running Programs

You can run Sixenine programs in two ways:

1. Interactive mode:
```bash
python -m sixenine.src.compiler
```

2. From a file:
```bash
python -m sixenine.src.run filename.sn
```

## Example Program

Check out the example program in `sixenine/examples/example.sn` that demonstrates various language features including a recursive Fibonacci implementation. To run it:

```bash
python -m sixenine.src.run sixenine/examples/example.sn
``` 